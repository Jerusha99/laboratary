package com.las.laboratory_appointment_system.enums;

public enum UserRole {
    DOCTOR,
    PATIENT,
    LAB_TECHNICIAN
}
