package com.las.laboratory_appointment_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratoryAppointmentSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
